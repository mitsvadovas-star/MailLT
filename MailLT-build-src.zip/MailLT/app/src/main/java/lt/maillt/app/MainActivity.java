package lt.maillt.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.Html;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.text.DateFormat;
import java.util.*;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.mail.*;
import javax.mail.internet.*;

public class MainActivity extends Activity {
    private static final int REQ_ATTACH = 5001;
    private static final String PREFS = "maillt";
    private static final String KEY_ACCOUNTS = "accounts";
    private static final String KS_ALIAS = "MailLT.AccountSecrets";

    private LinearLayout root, list;
    private TextView status;
    private android.content.SharedPreferences prefs;
    private final ArrayList<Account> accounts = new ArrayList<>();
    private final ArrayList<MailItem> inbox = new ArrayList<>();
    private final ArrayList<Uri> composeAttachments = new ArrayList<>();
    private EditText composeTo, composeSubject, composeBody;
    private LinearLayout composeAttachmentList;
    private Account composeAccount;
    private int pad;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        pad = dp(16);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadAccounts();
        if (accounts.isEmpty()) showAccountEditor(null); else showHome();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView tv(String s, int sp) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(Color.rgb(30,30,30));
        v.setPadding(pad, dp(9), pad, dp(9));
        return v;
    }

    private Button btn(String s) { Button b = new Button(this); b.setText(s); return b; }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value == null ? "" : value);
        e.setSingleLine(true); e.setPadding(pad, dp(8), pad, dp(8)); return e;
    }

    private void base(String title) {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(6), dp(12), dp(6), dp(32)); sv.addView(root);
        TextView t = tv(title, 25); t.setTextColor(Color.rgb(21,101,192)); root.addView(t);
        setContentView(sv);
    }

    private void showHome() {
        base("Mail LT");
        LinearLayout bar = new LinearLayout(this); bar.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = btn("Atnaujinti"), compose = btn("Rašyti"), acc = btn("Paskyros");
        bar.addView(refresh, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(compose, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(acc, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(bar);

        LinearLayout searchBar = new LinearLayout(this); searchBar.setOrientation(LinearLayout.HORIZONTAL);
        EditText q = field("Ieškoti laiškuose", ""); Button search = btn("Ieškoti");
        searchBar.addView(q, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1)); searchBar.addView(search);
        root.addView(searchBar);

        status = tv("", 14); root.addView(status);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);

        refresh.setOnClickListener(v -> loadInbox());
        compose.setOnClickListener(v -> showCompose(accounts.get(0), "", "", ""));
        acc.setOnClickListener(v -> showAccounts());
        search.setOnClickListener(v -> renderInbox(q.getText().toString().trim()));
        loadInbox();
    }

    private void showAccounts() {
        base("Paskyros");
        for (Account a : accounts) {
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
            TextView name = tv((a.name.isEmpty() ? a.email : a.name) + "\n" + a.email, 17);
            row.addView(name); Button edit = btn("Redaguoti"); row.addView(edit); edit.setOnClickListener(v -> showAccountEditor(a));
            root.addView(row); addGap();
        }
        Button add = btn("+ Pridėti paskyrą"), back = btn("Atgal"); root.addView(add); root.addView(back);
        add.setOnClickListener(v -> showAccountEditor(null)); back.setOnClickListener(v -> showHome());
    }

    private void showAccountEditor(Account existing) {
        base(existing == null ? "Nauja paskyra" : "Paskyros nustatymai");
        Account a = existing == null ? new Account() : existing.copy();

        LinearLayout presets = new LinearLayout(this); presets.setOrientation(LinearLayout.HORIZONTAL);
        Button gmail = btn("Gmail"), outlook = btn("Outlook"), custom = btn("Kitas");
        presets.addView(gmail, new LinearLayout.LayoutParams(0,-2,1)); presets.addView(outlook,new LinearLayout.LayoutParams(0,-2,1)); presets.addView(custom,new LinearLayout.LayoutParams(0,-2,1)); root.addView(presets);

        EditText name = field("Pavadinimas (pvz. Darbas)", a.name);
        EditText email = field("El. paštas", a.email);
        EditText pass = field("Slaptažodis / App Password", a.password); pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText imap = field("IMAP serveris", a.imapHost);
        EditText imapPort = field("IMAP portas", a.imapPort == 0 ? "" : String.valueOf(a.imapPort)); imapPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText smtp = field("SMTP serveris", a.smtpHost);
        EditText smtpPort = field("SMTP portas", a.smtpPort == 0 ? "" : String.valueOf(a.smtpPort)); smtpPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText sig = field("Parašas", a.signature); sig.setSingleLine(false); sig.setMinLines(3); sig.setGravity(Gravity.TOP);
        root.addView(name); root.addView(email); root.addView(pass); root.addView(imap); root.addView(imapPort); root.addView(smtp); root.addView(smtpPort); root.addView(sig);

        TextView note = tv("Gmail: naudok Google App Password. Outlook/Microsoft 365 paskyroms, kur Basic Auth išjungtas, reikės OAuth2 versijos.", 13); root.addView(note);
        Button save = btn("Išsaugoti"), test = btn("Patikrinti IMAP"), delete = btn("Pašalinti paskyrą"), back = btn("Atgal");
        root.addView(save); root.addView(test); if (existing != null) root.addView(delete); root.addView(back);

        gmail.setOnClickListener(v -> { imap.setText("imap.gmail.com"); imapPort.setText("993"); smtp.setText("smtp.gmail.com"); smtpPort.setText("465"); });
        outlook.setOnClickListener(v -> { imap.setText("outlook.office365.com"); imapPort.setText("993"); smtp.setText("smtp.office365.com"); smtpPort.setText("587"); });
        custom.setOnClickListener(v -> Toast.makeText(this,"Įvesk savo serverių adresus",Toast.LENGTH_SHORT).show());

        save.setOnClickListener(v -> {
            try {
                a.name = name.getText().toString().trim(); a.email = email.getText().toString().trim(); a.password = pass.getText().toString();
                a.imapHost = imap.getText().toString().trim(); a.imapPort = Integer.parseInt(imapPort.getText().toString().trim());
                a.smtpHost = smtp.getText().toString().trim(); a.smtpPort = Integer.parseInt(smtpPort.getText().toString().trim()); a.signature = sig.getText().toString();
                if (a.id.isEmpty()) a.id = UUID.randomUUID().toString();
                if (a.email.isEmpty() || a.password.isEmpty() || a.imapHost.isEmpty() || a.smtpHost.isEmpty()) throw new IllegalArgumentException("Užpildyk visus prisijungimo laukus");
                upsertAccount(a); saveAccounts(); Toast.makeText(this,"Išsaugota",Toast.LENGTH_SHORT).show(); showHome();
            } catch (Exception ex) { Toast.makeText(this,"Klaida: "+ex.getMessage(),Toast.LENGTH_LONG).show(); }
        });

        test.setOnClickListener(v -> {
            try {
                a.email = email.getText().toString().trim(); a.password = pass.getText().toString(); a.imapHost = imap.getText().toString().trim(); a.imapPort = Integer.parseInt(imapPort.getText().toString().trim());
                test.setEnabled(false); Toast.makeText(this,"Tikrinama…",Toast.LENGTH_SHORT).show();
                new Thread(() -> { try { testImap(a); runOnUiThread(() -> { test.setEnabled(true); Toast.makeText(this,"IMAP prisijungimas veikia",Toast.LENGTH_LONG).show(); }); }
                    catch (Exception ex) { runOnUiThread(() -> { test.setEnabled(true); Toast.makeText(this,"Nepavyko: "+cleanError(ex),Toast.LENGTH_LONG).show(); }); } }).start();
            } catch (Exception ex) { Toast.makeText(this,"Patikrink portą",Toast.LENGTH_SHORT).show(); }
        });

        if (existing != null) delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Pašalinti paskyrą?").setMessage(existing.email).setNegativeButton("Ne",null).setPositiveButton("Taip",(d,w)->{ accounts.removeIf(x -> x.id.equals(existing.id)); saveAccounts(); if(accounts.isEmpty()) showAccountEditor(null); else showHome(); }).show());
        back.setOnClickListener(v -> { if (accounts.isEmpty()) finish(); else showAccounts(); });
    }

    private void testImap(Account a) throws Exception {
        Properties pr = imapProps(a); Session s = Session.getInstance(pr); Store st = s.getStore("imaps");
        try { st.connect(a.imapHost, a.imapPort, a.email, a.password); } finally { try { st.close(); } catch (Exception ignored) {} }
    }

    private void loadInbox() {
        if (status == null || list == null) return;
        status.setText("Jungiamasi…"); list.removeAllViews();
        new Thread(() -> {
            ArrayList<MailItem> all = new ArrayList<>(); ArrayList<String> errors = new ArrayList<>();
            for (Account a : accounts) {
                try { all.addAll(fetchAccountInbox(a, 30)); }
                catch (Exception e) { errors.add(a.email + ": " + cleanError(e)); }
            }
            all.sort((x,y) -> Long.compare(y.dateMs, x.dateMs));
            runOnUiThread(() -> {
                inbox.clear(); inbox.addAll(all);
                String s = "Laiškų: " + all.size(); if (!errors.isEmpty()) s += "  •  Klaidos: " + errors.size(); status.setText(s);
                if (!errors.isEmpty()) status.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Prisijungimo klaidos").setMessage(joinLines(errors)).setPositiveButton("OK",null).show());
                renderInbox("");
            });
        }).start();
    }

    private ArrayList<MailItem> fetchAccountInbox(Account a, int limit) throws Exception {
        ArrayList<MailItem> out = new ArrayList<>(); Properties pr = imapProps(a); Session session = Session.getInstance(pr);
        Store store = session.getStore("imaps"); Folder folder = null;
        try {
            store.connect(a.imapHost, a.imapPort, a.email, a.password);
            folder = store.getFolder("INBOX"); folder.open(Folder.READ_ONLY);
            int count = folder.getMessageCount(); if (count <= 0) return out;
            int start = Math.max(1, count - limit + 1); Message[] msgs = folder.getMessages(start, count);
            FetchProfile fp = new FetchProfile(); fp.add(FetchProfile.Item.ENVELOPE); fp.add(FetchProfile.Item.FLAGS); folder.fetch(msgs, fp);
            for (int i = msgs.length - 1; i >= 0; i--) {
                Message m = msgs[i]; MailItem mi = new MailItem(); mi.accountId = a.id; mi.messageNumber = m.getMessageNumber();
                mi.subject = safe(m.getSubject(), "(be temos)"); mi.from = formatAddresses(m.getFrom());
                Date d = m.getReceivedDate(); if (d == null) d = m.getSentDate(); mi.dateMs = d == null ? 0 : d.getTime();
                mi.unread = !m.isSet(Flags.Flag.SEEN);
                BodyResult br = readBody(m, 16000); mi.body = br.text; mi.attachments.addAll(br.attachments); out.add(mi);
            }
        } finally {
            if (folder != null) try { folder.close(false); } catch (Exception ignored) {}
            try { store.close(); } catch (Exception ignored) {}
        }
        return out;
    }

    private Properties imapProps(Account a) {
        Properties p = new Properties(); p.setProperty("mail.store.protocol","imaps"); p.setProperty("mail.imaps.ssl.enable","true");
        p.setProperty("mail.imaps.connectiontimeout","15000"); p.setProperty("mail.imaps.timeout","20000"); p.setProperty("mail.imaps.writetimeout","20000"); return p;
    }

    private BodyResult readBody(Part part, int max) throws Exception {
        BodyResult r = new BodyResult(); collectBody(part, r, max); if (r.text == null) r.text = ""; if (r.text.length() > max) r.text = r.text.substring(0,max) + "\n\n[...trumpinta...]"; return r;
    }

    private void collectBody(Part part, BodyResult r, int max) throws Exception {
        String disp = part.getDisposition(); String name = part.getFileName();
        if (Part.ATTACHMENT.equalsIgnoreCase(disp) || (name != null && !name.isEmpty())) { r.attachments.add(decode(name == null ? "priedas" : name)); return; }
        if (part.isMimeType("text/plain")) {
            if (r.text == null || r.text.isEmpty()) r.text = String.valueOf(part.getContent()); return;
        }
        if (part.isMimeType("text/html")) {
            if (r.text == null || r.text.isEmpty()) r.text = Html.fromHtml(String.valueOf(part.getContent()), Html.FROM_HTML_MODE_LEGACY).toString(); return;
        }
        if (part.isMimeType("multipart/*")) {
            Multipart mp = (Multipart) part.getContent();
            for (int i=0;i<mp.getCount();i++) { collectBody(mp.getBodyPart(i), r, max); if (r.text != null && r.text.length() > max) break; }
        }
    }

    private void renderInbox(String query) {
        if (list == null) return; list.removeAllViews(); String q = query == null ? "" : query.toLowerCase(Locale.ROOT);
        int shown = 0;
        for (MailItem m : inbox) {
            String hay = (m.from+" "+m.subject+" "+m.body).toLowerCase(Locale.ROOT); if (!q.isEmpty() && !hay.contains(q)) continue;
            shown++; Account a = findAccount(m.accountId); LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(4),dp(5),dp(4),dp(5));
            TextView from = tv((m.unread ? "● " : "") + m.from, 15); TextView sub = tv(m.subject, 18); if (m.unread) sub.setTypeface(null, android.graphics.Typeface.BOLD);
            String meta = (a == null ? "" : (a.name.isEmpty()?a.email:a.name)+"  •  ") + formatDate(m.dateMs) + (m.attachments.isEmpty()?"":"  •  📎 " + m.attachments.size());
            TextView d = tv(meta, 12); row.addView(from); row.addView(sub); row.addView(d); row.setBackgroundColor(Color.rgb(247,249,252)); row.setOnClickListener(v -> showMessage(m)); list.addView(row); addGapTo(list);
        }
        if (shown == 0) list.addView(tv(q.isEmpty()?"Laiškų nėra":"Nieko nerasta",16));
    }

    private void showMessage(MailItem m) {
        Account a = findAccount(m.accountId); base(m.subject);
        root.addView(tv("Nuo: "+m.from,15)); root.addView(tv("Paskyra: "+(a==null?"":a.email),13)); root.addView(tv(formatDate(m.dateMs),13));
        if (!m.attachments.isEmpty()) root.addView(tv("Priedai: " + String.join(", ", m.attachments), 13));
        TextView body = tv(m.body,16); body.setTextIsSelectable(true); root.addView(body);
        LinearLayout bar = new LinearLayout(this); Button reply=btn("Atsakyti"), forward=btn("Persiųsti"), back=btn("Atgal");
        bar.addView(reply,new LinearLayout.LayoutParams(0,-2,1));bar.addView(forward,new LinearLayout.LayoutParams(0,-2,1));bar.addView(back,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);
        reply.setOnClickListener(v -> showCompose(a, extractEmail(m.from), "Re: "+stripReplyPrefix(m.subject), "\n\n---\n"+m.from+" rašė:\n"+m.body));
        forward.setOnClickListener(v -> showCompose(a, "", "Fwd: "+m.subject, "\n\n--- Persiųstas laiškas ---\nNuo: "+m.from+"\nTema: "+m.subject+"\n\n"+m.body));
        back.setOnClickListener(v -> showHome());
    }

    private void showCompose(Account account, String to0, String sub0, String body0) {
        if (account == null) account = accounts.get(0); composeAccount = account; composeAttachments.clear(); base("Naujas laiškas");
        if (accounts.size() > 1) {
            Spinner sp = new Spinner(this); ArrayList<String> labels = new ArrayList<>(); int sel=0; for(int i=0;i<accounts.size();i++){Account x=accounts.get(i);labels.add(x.name.isEmpty()?x.email:x.name+" — "+x.email);if(x.id.equals(account.id))sel=i;}
            sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels)); sp.setSelection(sel); sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){composeAccount=accounts.get(pos);}public void onNothingSelected(android.widget.AdapterView<?> p){}}); root.addView(sp);
        }
        composeTo = field("Kam",to0); composeSubject=field("Tema",sub0); composeBody=new EditText(this); composeBody.setHint("Laiškas"); composeBody.setMinLines(12); composeBody.setGravity(Gravity.TOP); composeBody.setText(body0);
        root.addView(composeTo); root.addView(composeSubject); root.addView(composeBody);
        Button attach=btn("📎 Prisegti failą"); composeAttachmentList=new LinearLayout(this); composeAttachmentList.setOrientation(LinearLayout.VERTICAL); root.addView(attach); root.addView(composeAttachmentList);
        LinearLayout bar=new LinearLayout(this);Button send=btn("Siųsti"),back=btn("Atgal");bar.addView(send,new LinearLayout.LayoutParams(0,-2,1));bar.addView(back,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);
        attach.setOnClickListener(v -> { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,REQ_ATTACH); });
        send.setOnClickListener(v -> {
            String to=composeTo.getText().toString().trim(),sub=composeSubject.getText().toString(),body=composeBody.getText().toString(); Account selected=composeAccount;
            if(to.isEmpty()){Toast.makeText(this,"Įvesk gavėją",Toast.LENGTH_SHORT).show();return;} send.setEnabled(false);
            new Thread(() -> { try { sendMail(selected,to,sub,body,new ArrayList<>(composeAttachments)); runOnUiThread(() -> {Toast.makeText(this,"Išsiųsta",Toast.LENGTH_LONG).show();showHome();}); }
                catch(Exception e){runOnUiThread(() -> {send.setEnabled(true);Toast.makeText(this,"Siuntimo klaida: "+cleanError(e),Toast.LENGTH_LONG).show();});} }).start();
        });
        back.setOnClickListener(v -> showHome());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if(requestCode!=REQ_ATTACH||resultCode!=RESULT_OK||data==null)return;
        if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++){Uri u=data.getClipData().getItemAt(i).getUri();composeAttachments.add(u);takeReadPermission(data,u);}}
        else if(data.getData()!=null){composeAttachments.add(data.getData());takeReadPermission(data,data.getData());}
        renderComposeAttachments();
    }

    private void takeReadPermission(Intent data, Uri u){try{getContentResolver().takePersistableUriPermission(u,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}

    private void renderComposeAttachments(){ if(composeAttachmentList==null)return;composeAttachmentList.removeAllViews();for(Uri u:composeAttachments){TextView t=tv("📎 "+displayName(u),13);t.setOnClickListener(v->{composeAttachments.remove(u);renderComposeAttachments();});composeAttachmentList.addView(t);} }

    private void sendMail(Account a, String to, String subject, String body, ArrayList<Uri> atts) throws Exception {
        Properties p = new Properties(); p.put("mail.smtp.auth","true"); p.put("mail.smtp.connectiontimeout","15000"); p.put("mail.smtp.timeout","20000");
        if(a.smtpPort==465){p.put("mail.smtp.ssl.enable","true");}else{p.put("mail.smtp.starttls.enable","true");p.put("mail.smtp.starttls.required","true");}
        Session s=Session.getInstance(p); MimeMessage m=new MimeMessage(s); m.setFrom(new InternetAddress(a.email)); m.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to,false)); m.setSubject(subject==null?"":subject,"UTF-8"); m.setSentDate(new Date());
        String text=body==null?"":body; if(a.signature!=null&&!a.signature.isEmpty())text += "\n\n"+a.signature;
        if(atts.isEmpty()){m.setText(text,"UTF-8");}else{MimeMultipart mp=new MimeMultipart();MimeBodyPart txt=new MimeBodyPart();txt.setText(text,"UTF-8");mp.addBodyPart(txt);for(Uri u:atts){MimeBodyPart bp=new MimeBodyPart();bp.setDataHandler(new DataHandler(new UriDataSource(u)));bp.setFileName(MimeUtility.encodeText(displayName(u),"UTF-8",null));mp.addBodyPart(bp);}m.setContent(mp);}
        Transport tr=s.getTransport("smtp");try{tr.connect(a.smtpHost,a.smtpPort,a.email,a.password);tr.sendMessage(m,m.getAllRecipients());}finally{try{tr.close();}catch(Exception ignored){}}
    }

    private class UriDataSource implements DataSource {
        private final Uri uri; UriDataSource(Uri u){uri=u;}
        public InputStream getInputStream() throws IOException {InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new FileNotFoundException(uri.toString());return in;}
        public OutputStream getOutputStream() throws IOException {throw new IOException("read only");}
        public String getContentType(){String t=getContentResolver().getType(uri);return t==null?"application/octet-stream":t;}
        public String getName(){return displayName(uri);}
    }

    private String displayName(Uri u){String n=null;Cursor c=null;try{c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst())n=c.getString(0);}catch(Exception ignored){}finally{if(c!=null)c.close();}return n==null?"priedas":n;}

    private void loadAccounts() {
        accounts.clear(); String raw=prefs.getString(KEY_ACCOUNTS,"[]");
        try { JSONArray a=new JSONArray(raw); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Account x=new Account();x.id=o.optString("id",UUID.randomUUID().toString());x.name=o.optString("name","");x.email=o.optString("email","");x.password=decrypt(o.optString("secret",""));x.imapHost=o.optString("imapHost","");x.imapPort=o.optInt("imapPort",993);x.smtpHost=o.optString("smtpHost","");x.smtpPort=o.optInt("smtpPort",465);x.signature=o.optString("signature","");accounts.add(x);} } catch(Exception ignored){}
    }

    private void saveAccounts() {
        try {JSONArray a=new JSONArray();for(Account x:accounts){JSONObject o=new JSONObject();o.put("id",x.id);o.put("name",x.name);o.put("email",x.email);o.put("secret",encrypt(x.password));o.put("imapHost",x.imapHost);o.put("imapPort",x.imapPort);o.put("smtpHost",x.smtpHost);o.put("smtpPort",x.smtpPort);o.put("signature",x.signature);a.put(o);}prefs.edit().putString(KEY_ACCOUNTS,a.toString()).apply();}
        catch(Exception e){Toast.makeText(this,"Nepavyko saugiai išsaugoti paskyros",Toast.LENGTH_LONG).show();}
    }

    private String encrypt(String plain) throws Exception {if(plain==null||plain.isEmpty())return "";SecretKey key=getSecretKey();Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key);byte[] iv=c.getIV(),ct=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));return Base64.getEncoder().encodeToString(iv)+":"+Base64.getEncoder().encodeToString(ct);}
    private String decrypt(String enc) {try{if(enc==null||enc.isEmpty())return "";String[] p=enc.split(":",2);SecretKey key=getSecretKey();Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,Base64.getDecoder().decode(p[0])));return new String(c.doFinal(Base64.getDecoder().decode(p[1])),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    private SecretKey getSecretKey() throws Exception {KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(KS_ALIAS))return (SecretKey)ks.getKey(KS_ALIAS,null);KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder(KS_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return kg.generateKey();}

    private void upsertAccount(Account a){for(int i=0;i<accounts.size();i++)if(accounts.get(i).id.equals(a.id)){accounts.set(i,a);return;}accounts.add(a);}
    private Account findAccount(String id){for(Account a:accounts)if(a.id.equals(id))return a;return accounts.isEmpty()?null:accounts.get(0);}
    private String cleanError(Throwable e){String m=e.getMessage();if(m==null||m.trim().isEmpty())m=e.getClass().getSimpleName();return m.replaceAll("(?i)password=[^ ]+","password=***");}
    private String formatAddresses(Address[] a){if(a==null||a.length==0)return "";StringBuilder b=new StringBuilder();for(Address x:a){if(b.length()>0)b.append(", ");if(x instanceof InternetAddress){InternetAddress ia=(InternetAddress)x;String p=ia.getPersonal();b.append(p==null||p.isEmpty()?ia.getAddress():decode(p)+" <"+ia.getAddress()+">");}else b.append(x.toString());}return b.toString();}
    private String decode(String s){try{return MimeUtility.decodeText(s);}catch(Exception e){return s;}}
    private String formatDate(long ms){return ms<=0?"":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,new Locale("lt","LT")).format(new Date(ms));}
    private String extractEmail(String s){try{InternetAddress[] a=InternetAddress.parse(s,false);return a.length==0?s:a[0].getAddress();}catch(Exception e){int x=s.indexOf('<'),y=s.indexOf('>');return x>=0&&y>x?s.substring(x+1,y):s;}}
    private String stripReplyPrefix(String s){return s==null?"":s.replaceFirst("(?i)^re:\\s*","");}
    private String safe(String s,String d){return s==null||s.trim().isEmpty()?d:decode(s);}
    private String joinLines(List<String> xs){StringBuilder b=new StringBuilder();for(String x:xs){if(b.length()>0)b.append("\n\n");b.append(x);}return b.toString();}
    private void addGap(){Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(10)));}
    private void addGapTo(LinearLayout l){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,dp(7)));}

    @Override public void onBackPressed() { if (accounts.isEmpty()) super.onBackPressed(); else showHome(); }

    static class Account {String id="",name="",email="",password="",imapHost="",smtpHost="",signature="";int imapPort=993,smtpPort=465;Account copy(){Account a=new Account();a.id=id;a.name=name;a.email=email;a.password=password;a.imapHost=imapHost;a.imapPort=imapPort;a.smtpHost=smtpHost;a.smtpPort=smtpPort;a.signature=signature;return a;}}
    static class MailItem {String accountId="",from="",subject="",body="";int messageNumber;long dateMs;boolean unread;ArrayList<String> attachments=new ArrayList<>();}
    static class BodyResult {String text="";ArrayList<String> attachments=new ArrayList<>();}
}
